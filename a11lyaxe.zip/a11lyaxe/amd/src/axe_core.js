define(['atto_a11lyaxe/config', 'axe_core'], function(unused, Axe) {
    return Axe;
    }
);

